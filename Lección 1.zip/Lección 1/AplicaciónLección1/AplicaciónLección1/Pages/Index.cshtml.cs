using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AplicaciónLección1.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}
