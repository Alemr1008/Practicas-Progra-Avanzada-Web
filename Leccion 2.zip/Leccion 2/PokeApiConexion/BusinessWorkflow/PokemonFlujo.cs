﻿using PokeApiConexion.Models;
using PokeApiConexion.ServiceGateway;
using PokeApiConexion.Models.PokeApi;

namespace PokeApiConexion.BusinessWorkflow
{
    public class PokemonFlujo : IPokemonFlujo
    {
        private const string UrlImagen = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/";

        private readonly IPokeApiServicio _pokeApi;

        public PokemonFlujo(IPokeApiServicio pokeApi)
        {
            _pokeApi = pokeApi;
        }

        public async Task<Pokemon?> ObtenerPokemonAsync(string nombreOId)
        {
            var respuesta = await _pokeApi.ObtenerPokemonAsync(nombreOId);
            return respuesta == null ? null : Mapear(respuesta);
        }
        public async Task<PaginaPokemon?> ListarAsync(int pagina, int cantidad)
        {
            pagina = Math.Max(1, pagina);
            cantidad = Math.Clamp(cantidad, 1, 50);
            var offset = (pagina - 1) * cantidad;
            var lista = await _pokeApi.ObtenerListaAsync(offset, cantidad);

            return new PaginaPokemon
            {
                Total = lista?.Count ?? 0,
                Pagina = pagina,
                Cantidad = cantidad,
                Resultados = lista.Results.Select(CrearResumen).ToList() ?? new()
            };
        }

        public async Task<List<PokemonResumen>?> ListarPorTipoAsync(string tipo)
        {
            var respuesta = await _pokeApi.ObtenerTipoAsync(tipo);
            return respuesta?.Pokemon.Select(p => CrearResumen(p.Pokemon)).ToList();
        }

        public async Task<Comparacion?> CompararAsync(string pokemon1, string pokemon2)
        {
            var p1 = ObtenerPokemonAsync(pokemon1);
            var p2 = ObtenerPokemonAsync(pokemon2);
            await Task.WhenAll(p1, p2);

            var p1Result = p1.Result;
            var p2Result = p2.Result;

            if (p1Result == null || p2Result == null)
                return null;
            return new Comparacion
            {
                Pokemon1 = p1Result,
                Pokemon2 = p2Result,
                Ganador = p1Result.TotalEstadisticas == p2Result.TotalEstadisticas ? "Empate" : (p1Result.TotalEstadisticas > p2Result.TotalEstadisticas ? p1Result.Nombre : p2Result.Nombre),
                Diferencia = Math.Abs(p1Result.TotalEstadisticas - p2Result.TotalEstadisticas)
            };
        }

        public static Pokemon Mapear(PokemonRespuesta respuesta) => new()
        {

            Id = respuesta.Id,
            Nombre = respuesta.Name,
            AlturaMetros = respuesta.Height / 10m,
            PesoKg = respuesta.Weight / 10m,
            ExperienciaBase = respuesta.BaseExperience ?? 0,
            Imagen = respuesta.Sprites?.Other?.OfficialArtwork?.FrontDefault ?? respuesta.Sprites?.FrontDefault,
            Tipos = respuesta.Types.OrderBy(t => t.Slot).Select(t => t.Type.Name).ToList(),
            Habilidades = respuesta.Abilities.Select(h => h.IsHidden ? $"{h.Ability.Name} (Oculta)" : h.Ability.Name).ToList(),
            Estadisticas = respuesta.Stats.Select(e => new Estadistica { Nombre = e.Stat.Name, Valor = e.BaseStat }).ToList()
        };

        public static PokemonResumen CrearResumen(RecursoConNombre recurso)
        {
            var id = int.Parse(recurso.Url.TrimEnd('/').Split('/').Last());
            return new PokemonResumen
            {
                Id = id,
                Nombre = recurso.Name,
                Imagen = string.Format(UrlImagen, id)
            };
        }
    }
}
