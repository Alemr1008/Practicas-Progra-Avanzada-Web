using PokeApiConexion.BusinessWorkflow;
using PokeApiConexion.ServiceGateway;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddHttpClient<IPokeApiServicio, PokeApiServicio>(client =>
{
    client.BaseAddress = new Uri(builder.Configuration["PokeApi:UrlBase"]!);
});

// Registrar IPokemonFlujo en el contenedor de DI
builder.Services.AddScoped<IPokemonFlujo, PokemonFlujo>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
