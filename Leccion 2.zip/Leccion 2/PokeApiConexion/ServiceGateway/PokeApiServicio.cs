﻿using PokeApiConexion.Models.PokeApi;
using System.Net;

namespace PokeApiConexion.ServiceGateway
{
    public class PokeApiServicio : IPokeApiServicio
    {
        private readonly HttpClient _httpClient;

        public PokeApiServicio(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<PokemonRespuesta?> ObtenerPokemonAsync(string nombreOId)
        {
            var respuesta = await _httpClient.GetAsync($"pokemon/{nombreOId.Trim().ToLower()}");
            if (respuesta.StatusCode == HttpStatusCode.NotFound)
            {
                return null;
            }
            respuesta.EnsureSuccessStatusCode();
            return await respuesta.Content.ReadFromJsonAsync<PokemonRespuesta>();
        }

        public async Task<ListaRespuesta?> ObtenerListaAsync(int offset, int limit)
        {
            return await _httpClient.GetFromJsonAsync<ListaRespuesta>($"pokemon?offset={offset}&limit={limit}");
        }

        public async Task<TipoRespuesta?> ObtenerTipoAsync(string tipo)
        {
            var respuesta = await _httpClient.GetAsync($"type/{tipo.Trim().ToLower()}");
            if (respuesta.StatusCode == HttpStatusCode.NotFound)
            {
                return null;
            }
            respuesta.EnsureSuccessStatusCode();
            return await respuesta.Content.ReadFromJsonAsync<TipoRespuesta>();
        }
    }
}
