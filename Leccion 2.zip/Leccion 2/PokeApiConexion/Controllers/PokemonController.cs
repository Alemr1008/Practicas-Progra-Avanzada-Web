﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PokeApiConexion.BusinessWorkflow;

namespace PokeApiConexion.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PokemonController : ControllerBase
    {
        private readonly IPokemonFlujo _flujo;

        public PokemonController(IPokemonFlujo flujo)
        {
            _flujo = flujo;
        }

        [HttpGet]
        public async Task<IActionResult> Listar(int pagina = 1, int cantidad = 20)
        {
            var resultado = await _flujo.ListarAsync(pagina, cantidad);
            return Ok(resultado);
        }
        [HttpGet("{nombreOId}")]
        public async Task<IActionResult> Obtener(string nombreOId)
        {
            var resultado = await _flujo.ObtenerPokemonAsync(nombreOId);
            if (resultado == null)
                return NotFound($"No existe un Pokemon llamado '{nombreOId}'");
            return Ok(resultado);
        }

        [HttpGet("tipo/{tipo}")]
        public async Task<IActionResult> ListarPorTipo(string tipo)
        {
            var resultado = await _flujo.ListarPorTipoAsync(tipo);
            if (resultado == null || !resultado.Any())
                return NotFound($"No existen Pokemons del tipo '{tipo}'");
            return Ok(resultado);
        }


        [HttpGet("comparar")]
        public async Task<IActionResult> Comparar(string? pokemon1, string? pokemon2)
        {
            if (string.IsNullOrWhiteSpace(pokemon1) || string.IsNullOrWhiteSpace(pokemon2))
                return BadRequest("Debe especificar los nombres o IDs de ambos Pokemons a comparar.");
            var comparacion = await _flujo.CompararAsync(pokemon1, pokemon2);
            if (comparacion == null)
                return NotFound($"No se pudo realizar la comparación entre '{pokemon1}' y '{pokemon2}'");
            return Ok(comparacion);
        }
    }
}
